//efeito do botão voltar ao Topo

//Validação de Login

//Ativar alert no botão cadastrar
